package com.advisorApp.roboadvisorapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoboadvisorappApplicationTests {

	@Test
	void contextLoads() {
	}

}
